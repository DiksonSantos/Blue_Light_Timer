#!/home/dikson/.MiniConda_/envs/Dados/bin/python
# coding: utf-8

# 07/05/2026 -> Adicionada Transição suave para troca de Temperatura & Brilho.
# 13/05/2026 -> Adicionado período late_night (21h–00h), meio-termo entre evening e night.
# 08/06/2026 -> Controle automático de frequência do eDP-1: 144Hz na tomada, 60Hz na bateria.
# 08/06/2026 -> Brilho eDP-1 reduzido 35% na bateria; HDMI não é afetado.
# 14/08/2026 -> Ajustadas temperaturas morning/evening e alinhado expected_sct_gamma.
# 16/08/2026 -> Diversas correções de robustez: cache do HDMI/eDP-1/brilho agora
#              confere o estado real antes de pular (não só a memória do
#              script); corrigida inversão de gamma do driver NVIDIA e regex
#              quebrada do eDP-1; perfis alternáveis por CPU governor
#              (evening: gaming/movie, afternoon: gaming/normal); brilho
#              máximo real do painel corrigido para 19200 (era 14400).
#              Detalhe de cada correção comentado perto do código relevante.
# 17/08/2026 -> Resolvido o problema de convergência que estava fazendo o HDMI piscar durante o período da manhã.
# 19/09/2026 -> HDMI agora usa redshift (ganho linear por canal + brilho na MESMA
#              rampa, só no CRTC do HDMI) em vez de xrandr --gamma. O --gamma é uma
#              curva de potência e nunca esquenta o branco; o ganho linear (como o
#              sct faz no eDP) esquenta todos os tons, inclusive o branco. O CRTC é
#              descoberto a cada ciclo. O gamma_hdmi dos SETTINGS virou só fallback
#              (usado se o redshift não estiver instalado ou HDMI_USE_REDSHIFT=False).
# __

import subprocess
from datetime import datetime, time as dtime
import time
import re
import shutil
from hora_certa import get_today_sun_times

"""
PARAR SERVIÇO;
systemctl --user stop pos_blue.service

IMPEDIR QUE REINICIE AUTOMATICAMENTE;
systemctl --user stop pos_blue.service && systemctl --user disable pos_blue.service

CONFIRMAR QUE PAROU;
systemctl --user status pos_blue.service

REATIVAR;
systemctl --user enable --now pos_blue.service

"""


# === CONFIGURAÇÕES GERAIS ===
BRIGHTNESS_PATH = "/sys/class/backlight/intel_backlight/brightness"
LOG_FILE = "/tmp/pos_Blue_Brilho.log"
HDMI_OUTPUT = "HDMI-1-0"
EDP_OUTPUT  = "eDP-1"

# Caminhos para detecção de fonte de energia
AC_ONLINE_PATH = "/sys/class/power_supply/ACAD/online"

# Frequências alvo por fonte de energia
HZ_ON_AC      = 144.00
HZ_ON_BATTERY = 60.01

# Modo de resolução fixo do eDP-1 (deve bater com o listado em xrandr)
EDP_MODE = "1920x1080"

# Estado da última frequência aplicada (evita reaplicação desnecessária)
_last_edp_hz = None

# Fator de redução de brilho do eDP-1 quando na bateria (0.65 = 35% menos)
BATTERY_BRIGHTNESS_FACTOR = 0.65

# Estado do último brilho aplicado (evita escrita desnecessária no backlight)
_last_brightness = None

# Estado do último gamma/brilho aplicados no HDMI (evita reaplicar xrandr sem necessidade,
# que é o que causa o piscar do monitor externo — antes era chamado todo ciclo, sempre)
_last_hdmi_gamma = None
_last_hdmi_brightness = None

# Duração da janela de transição em minutos (ex: 20 = 10 min antes e 10 min depois da virada)
TRANSITION_MINUTES = 1

# Horário fixo de início da madrugada profunda (late_night → night)
LATE_NIGHT_START = dtime(21, 0)

# === CONFIGURAÇÕES OTIMIZADAS PARA HDMI ===
# 14/08/2026 -> Ajustes de temperatura/brilho:
#              morning 4500K → 4000K
#              evening 3500K → 4300K
#              Demais valores mantidos conforme configuração atual.
# 16/08/2026 -> evening agora tem dois perfis, alternados automaticamente
#              pelo CPU governor (ver EVENING_PROFILES / update_evening_profile):
#              performance (jogos AAA) → 4300K | qualquer outro → 3500K (filmes/vídeos)
SETTINGS = {
    "morning": {
        "brightness": 9060,
        "color_temp": 4000,
        "gamma_hdmi": "1.00:0.95:0.90",
        "hdmi_brightness": 0.80
    },
    "afternoon": {
        # Valor inicial (será sobrescrito por update_afternoon_profile() a
        # cada ciclo do loop, de acordo com o CPU governor — mesmo esquema
        # do evening). Mantido aqui só para o script funcionar mesmo antes
        # da primeira checagem do governor.
        "brightness": 14400,
        "color_temp": 6500,
        "gamma_hdmi": "1.00:1.00:1.00",
        "hdmi_brightness": 1.00
    },
    "evening": {
        # Valor inicial (será sobrescrito por update_evening_profile() a cada
        # ciclo do loop, de acordo com o CPU governor). Mantido aqui só para
        # o script funcionar mesmo antes da primeira checagem do governor.
        "brightness": 4000,
        "color_temp": 3500,
        "gamma_hdmi": "1.00:0.90:0.60",
        "hdmi_brightness": 0.50
    },
    "late_night": {
        "brightness": 2200,          # meio-termo entre evening(4000) e night(1000)
        "color_temp": 3000,          # meio-termo entre evening(atual) e night(2700)
        "gamma_hdmi": "1.00:0.80:0.35",  # meio-termo entre evening e night
        "hdmi_brightness": 0.40      # meio-termo entre evening(0.50) e night(0.30)
    },
    "night": {
        "brightness": 1000,
        "color_temp": 2700,
        "gamma_hdmi": "1.00:0.70:0.15",
        "hdmi_brightness": 0.30
    }
}

# === PERFIS DO PERÍODO EVENING (alternados pelo CPU governor) ===
# gaming: usado quando o governor está em 'performance' (jogos AAA) — mais
#         frio/vívido (color_temp) e mais claro (brightness), pra ver detalhe
#         em jogos com cenas escuras (RE9 Requiem, Mafia: The Old Country,
#         Ace Combat 7) sem forçar a vista.
# movie:  usado em qualquer outro governor — mais quente e mais escuro,
#         melhor pra assistir filmes/vídeos por muito tempo sem cansar.
# gamma_hdmi e hdmi_brightness ficam iguais nos dois perfis (só afetam o
# monitor HDMI externo, não o brilho do painel interno).
EVENING_PROFILES = {
    "gaming": {
        "brightness": 7000,   # 16/08/2026: subido de 4000 → 7000 a pedido,
                               # pra melhor visibilidade em jogos escuros
        "color_temp": 4300,
        "gamma_hdmi": "1.00:0.90:0.60",
        "hdmi_brightness": 0.50
    },
    "movie": {
        "brightness": 4000,
        "color_temp": 3500,
        "gamma_hdmi": "1.00:0.90:0.60",
        "hdmi_brightness": 0.50
    }
}

# Caminho do governor da CPU (cpu0 como referência — a maioria dos sistemas
# usa a mesma política de governor em todos os núcleos)
CPU_GOVERNOR_PATH = "/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor"

# Governor que caracteriza "jogo AAA rodando" (gamemode, feral gamemode,
# powerprofilesctl, etc. tipicamente forçam 'performance' nesse momento)
GAMING_GOVERNOR = "performance"

# Estado do último perfil evening aplicado (só pra log, não crítico)
_last_evening_profile = None

def get_cpu_governor():
    """Lê o governor atual da CPU. Retorna None se não conseguir ler
    (ex: rodando em sandbox/VM sem cpufreq, ou CPU sem esse sysfs)."""
    try:
        with open(CPU_GOVERNOR_PATH, "r") as f:
            return f.read().strip()
    except Exception as e:
        log_message(f"Erro ao ler CPU governor: {e}")
        return None

def update_evening_profile():
    """
    Escolhe o perfil do 'evening' com base no CPU governor atual e atualiza
    SETTINGS['evening'] in-place. Chamado a cada ciclo do loop principal,
    então a troca de perfil (ex: ao abrir/fechar um jogo AAA) é detectada
    em poucos segundos, sem precisar reiniciar o serviço.
    """
    global _last_evening_profile

    governor = get_cpu_governor()
    profile_name = "gaming" if governor == GAMING_GOVERNOR else "movie"
    SETTINGS["evening"] = EVENING_PROFILES[profile_name]

    if profile_name != _last_evening_profile:
        log_message(
            f"Perfil evening → {profile_name.upper()} "
            f"(governor='{governor}', {SETTINGS['evening']['color_temp']}K)"
        )
        _last_evening_profile = profile_name

# === PERFIS DO PERÍODO AFTERNOON (alternados pelo CPU governor) ===
# 16/08/2026 -> Mesmo esquema do evening: à tarde o painel já roda em 75%
#              (14400/19200) por padrão, o que é confortável pro dia a dia,
#              mas pode ficar justo pra ver detalhe em cenas escuras de
#              jogos AAA (RE9 Requiem, Mafia: The Old Country, Ace Combat 7)
#              com luz de sol na sala. Quando o governor indica jogo AAA
#              rodando (performance), sobe pro brilho máximo do painel.
# gaming: brilho no máximo (100% = 19200) — cor/gamma já são neutros no
#         afternoon padrão, então não precisam mudar, só o brilho.
# normal: mantém os 75% (14400) de sempre, pra uso comum durante o dia.
AFTERNOON_PROFILES = {
    "gaming": {
        "brightness": 19200,
        "color_temp": 6500,
        "gamma_hdmi": "1.00:1.00:1.00",
        "hdmi_brightness": 1.00
    },
    "normal": {
        "brightness": 14400,
        "color_temp": 6500,
        "gamma_hdmi": "1.00:1.00:1.00",
        "hdmi_brightness": 1.00
    }
}

# Estado do último perfil afternoon aplicado (só pra log, não crítico)
_last_afternoon_profile = None

def update_afternoon_profile():
    """
    Escolhe o perfil do 'afternoon' com base no CPU governor atual e
    atualiza SETTINGS['afternoon'] in-place. Mesma lógica de
    update_evening_profile(), chamada a cada ciclo do loop principal.
    """
    global _last_afternoon_profile

    governor = get_cpu_governor()
    profile_name = "gaming" if governor == GAMING_GOVERNOR else "normal"
    SETTINGS["afternoon"] = AFTERNOON_PROFILES[profile_name]

    if profile_name != _last_afternoon_profile:
        log_message(
            f"Perfil afternoon → {profile_name.upper()} "
            f"(governor='{governor}', brilho={SETTINGS['afternoon']['brightness']})"
        )
        _last_afternoon_profile = profile_name

# === CACHE DE TEMPOS DE TRANSIÇÃO DIÁRIA ===
_DAILY_TRANSITION_CACHE = {"day": -1, "times": None}

def get_daily_transitions():
    """Retorna os horários de transição (MORNING/EVENING) baseados no nascer/pôr do sol de HOJE."""
    global _DAILY_TRANSITION_CACHE
    now = datetime.now()

    if now.day != _DAILY_TRANSITION_CACHE["day"]:
        log_message(f"--- RECALCULANDO: Novo dia ({now.day}) ---")
        try:
            sun_times = get_today_sun_times()
            _DAILY_TRANSITION_CACHE["times"] = sun_times
            _DAILY_TRANSITION_CACHE["day"] = now.day
        except Exception as e:
            log_message(f"ERRO ao calcular sun times: {e}. Usando fallback.")
            _DAILY_TRANSITION_CACHE["times"] = {
                "MORNING_START": dtime(6, 30),
                "EVENING_START": dtime(18, 00)
            }

    times = _DAILY_TRANSITION_CACHE["times"]

    return {
        "NIGHT_START":      dtime(0, 0),
        "AFTERNOON_START":  dtime(12, 0),
        "MORNING_START":    times["MORNING_START"],
        "EVENING_START":    times["EVENING_START"],
        "LATE_NIGHT_START": LATE_NIGHT_START        # fixo: 21h
    }


# === FUNÇÕES AUXILIARES ===

def log_message(message):
    with open(LOG_FILE, "a") as log:
        log.write(f"{datetime.now()} - {message}\n")

def is_monitor_off():
    try:
        result = subprocess.check_output("xset -display :0 q", shell=True, text=True, timeout=5)
        return "Monitor is Off" in result
    except:
        return False

def get_current_brightness_raw():
    """Lê o valor ATUAL do backlight direto do arquivo (só leitura)."""
    try:
        with open(BRIGHTNESS_PATH, 'r') as f:
            return int(f.read().strip())
    except Exception as e:
        log_message(f"Erro ao ler brilho principal atual: {e}")
        return None

def set_brightness(value):
    global _last_brightness
    # Aplica fator de bateria apenas no eDP-1 (este path controla só a tela embutida)
    effective = int(value * BATTERY_BRIGHTNESS_FACTOR) if not is_on_ac() else int(value)

    # 16/08/2026 -> O cache em memória (_last_brightness) não bastava: se algo
    #              externo mudar o brilho (Ctrl+seta, outro programa, etc), o
    #              cache continua achando que está tudo certo e nunca corrige.
    #              Mesmo bug de fundo do HDMI (cache sem confirmação real) —
    #              agora sempre confere o valor real do arquivo antes de pular.
    if _last_brightness == effective:
        current = get_current_brightness_raw()
        if current == effective:
            log_message(f"Brilho principal {effective} OK (confirmado) → brilho pulado")
            return
        else:
            log_message(f"Brilho principal drift detectado (real: {current}, esperado: {effective}) → reaplicando")

    try:
        with open(BRIGHTNESS_PATH, 'w') as f:
            f.write(str(effective))
        source_label = "AC" if is_on_ac() else f"bateria ×{BATTERY_BRIGHTNESS_FACTOR}"
        log_message(f"Brilho principal → {effective} ({source_label})")
        _last_brightness = effective
    except Exception as e:
        log_message(f"Erro brilho principal: {e}")

def get_current_gamma_primary():
    try:
        output = subprocess.check_output(
            "xrandr --verbose", shell=True, text=True, timeout=5
        )
        in_block = False
        for line in output.splitlines():
            if re.match(rf'^{re.escape(EDP_OUTPUT)}\s', line):
                in_block = True
                continue
            if in_block and re.match(r'^\S', line):
                break
            if in_block:
                m = re.search(r"Gamma:\s*([\d.]+):([\d.]+):([\d.]+)", line)
                if m:
                    return f"{m.group(1)}:{m.group(2)}:{m.group(3)}"
        return None
    except Exception as e:
        log_message(f"Erro ao ler gamma: {e}")
        return None

def gamma_close(g_a, g_b, tol=0.06):
    """
    Compara duas strings de gamma 'R:G:B' com tolerância numérica.
    Necessário porque o xrandr arredonda/quantiza o gamma ao ler de volta
    (ex: 1.0:1.22:1.49 configurado vira 1.0:1.2:1.5 no 'xrandr --verbose'),
    então uma comparação de string exata nunca bate e o sct fica sendo
    reaplicado a cada ciclo sem necessidade.

    17/08/2026 -> Corrigido bug de fronteira: 1.25 e 1.65 (valores de
    4000K na tabela expected_sct_gamma) caem em casos de arredondamento
    de ponto flutuante que resultam em 1.3 e 1.6 na leitura do xrandr —
    uma diferença de EXATAMENTE 0.05. A comparação usava '<' estrito, e
    '0.05 < 0.05' é False, então o gamma correto era rejeitado pra sempre
    a cada ciclo (nunca convergia), disparando 'sct' sem necessidade a
    cada ~5s. Como o sct mexe na rampa de TODA a tela (ver apply_sct),
    isso também forçava reaplicação constante do HDMI — causando o
    piscar. Trocado '<' por '<=' e tolerância de 0.05 para 0.06, com
    margem de segurança sobre esse arredondamento de borda.
    """
    if not g_a or not g_b:
        return False
    try:
        ra, ga, ba = [float(x) for x in g_a.split(":")]
        rb, gb, bb = [float(x) for x in g_b.split(":")]
    except ValueError:
        return False
    return abs(ra - rb) <= tol and abs(ga - gb) <= tol and abs(ba - bb) <= tol

def apply_sct(temp):
    global _last_hdmi_gamma, _last_hdmi_brightness
    try:
        subprocess.call(f"sct {int(temp)}", shell=True)
        log_message(f"sct {int(temp)}K → principal")
        # sct mexe na rampa de gamma da TELA inteira (todos os outputs do X,
        # não só o eDP-1) — então qualquer chamada aqui também bagunça o
        # gamma/brilho do HDMI. Invalida o cache do HDMI para forçar
        # reaplicação logo em seguida, no mesmo ciclo do loop.
        _last_hdmi_gamma = None
        _last_hdmi_brightness = None
    except Exception as e:
        log_message(f"Erro sct: {e}")

# 16/08/2026 -> Descoberto (via teste manual com gamma 0.30:0.30:0.30) que o
#              driver proprietário NVIDIA (550.163.01) aplica o --gamma do
#              xrandr CORRETAMENTE no hardware, mas ao ler de volta via
#              'xrandr --verbose' reporta o valor INVERTIDO (1/gamma), não o
#              valor real. Ex: pedimos 0.30 → aplica 0.30 na tela, mas o
#              --verbose mostra 3.3 (=1/0.30). Isso fazia o script achar que
#              havia "drift" pra sempre e martelar o xrandr a cada ciclo,
#              mesmo com a aplicação já correta — é o que causava o piscar.
#              Corrigido invertendo o valor lido antes de comparar.
def invert_gamma(g):
    """Inverte cada canal 'R:G:B' (1/x). Usado para corrigir a leitura
    invertida que o driver NVIDIA expõe via xrandr --verbose."""
    if not g:
        return None
    try:
        r, gg, b = [float(x) for x in g.split(":")]
        return f"{1/r if r else 0}:{1/gg if gg else 0}:{1/b if b else 0}"
    except (ValueError, ZeroDivisionError):
        return None

def get_current_hdmi_state():
    """
    Lê o gamma e o brilho ATUAIS do HDMI-1-0 direto do xrandr --verbose
    (só leitura — não reseta nada, então não causa piscar).
    O gamma lido é invertido (1/x) antes de retornar, pois o driver NVIDIA
    reporta o valor invertido em relação ao que foi realmente aplicado
    (ver nota de 16/08/2026 acima).
    Retorna (gamma_str, brightness_float) ou (None, None) se não conseguir ler.
    """
    try:
        output = subprocess.check_output("xrandr --verbose", shell=True, text=True, timeout=5)
        in_block = False
        gamma_raw = None
        brightness = None
        for line in output.splitlines():
            if re.match(rf'^{re.escape(HDMI_OUTPUT)}\s', line):
                in_block = True
                continue
            if in_block and re.match(r'^\S', line):
                break
            if in_block:
                m = re.search(r"Gamma:\s*([\d.]+):([\d.]+):([\d.]+)", line)
                if m:
                    gamma_raw = f"{m.group(1)}:{m.group(2)}:{m.group(3)}"
                m2 = re.search(r"Brightness:\s*([\d.]+)", line)
                if m2:
                    brightness = float(m2.group(1))
        gamma = invert_gamma(gamma_raw)
        return gamma, brightness
    except Exception as e:
        log_message(f"Erro ao ler estado atual do HDMI: {e}")
        return None, None

# Cooldown entre tentativas de reaplicar o MESMO alvo que já falhou —
# evita martelar 'xrandr' a cada 2-3s (o que pode voltar a causar o piscar)
# quando o comando roda mas não muda nada no hardware por algum motivo
# (ex: CRTC do HDMI ainda instável logo após replug do cabo).
HDMI_RETRY_COOLDOWN_SECONDS = 10
_last_hdmi_attempt_target = (None, None)  # (gamma, brightness) da última tentativa
_last_hdmi_attempt_time = 0.0

def apply_hdmi_gamma_brightness(gamma, brightness):
    global _last_hdmi_gamma, _last_hdmi_brightness
    global _last_hdmi_attempt_target, _last_hdmi_attempt_time

    # Arredonda para não recriar micro-diferenças de ponto flutuante entre ciclos
    brightness_r = round(brightness, 3)

    # O cache acha que já está certo — mas confirma com o estado REAL do X
    # antes de confiar (algo externo pode ter resetado o HDMI: DPMS/standby
    # do monitor, replug do cabo, outro xrandr, etc). É só uma leitura,
    # então não tem risco de piscar.
    if _last_hdmi_gamma == gamma and _last_hdmi_brightness == brightness_r:
        current_gamma, current_brightness = get_current_hdmi_state()
        brightness_ok = current_brightness is not None and abs(current_brightness - brightness_r) < 0.02
        if gamma_close(current_gamma, gamma) and brightness_ok:
            log_message(f"HDMI {gamma} | {brightness_r:.3f} OK (confirmado) → xrandr pulado")
            return
        else:
            log_message(
                f"HDMI drift detectado (real: {current_gamma} | {current_brightness}, "
                f"esperado: {gamma} | {brightness_r:.3f}) → reaplicando"
            )

    # Cooldown: se já tentamos EXATAMENTE esse mesmo alvo recentemente e não
    # deu certo (senão o cache/confirmação acima teria pulado), espera antes
    # de tentar de novo — evita martelar o xrandr a cada ciclo sem sucesso.
    now_ts = time.time()
    same_target = (_last_hdmi_attempt_target == (gamma, brightness_r))
    if same_target and (now_ts - _last_hdmi_attempt_time) < HDMI_RETRY_COOLDOWN_SECONDS:
        log_message(
            f"HDMI: última tentativa p/ {gamma} | {brightness_r:.3f} foi há menos de "
            f"{HDMI_RETRY_COOLDOWN_SECONDS}s e não confirmou → aguardando cooldown"
        )
        return

    _last_hdmi_attempt_target = (gamma, brightness_r)
    _last_hdmi_attempt_time = now_ts

    cmd = f"xrandr --output {HDMI_OUTPUT} --gamma {gamma} --brightness {brightness_r:.3f}"
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode != 0:
            log_message(
                f"xrandr HDMI retornou erro (code={result.returncode}): "
                f"{result.stderr.strip() or '(sem mensagem)'}"
            )
            # Não atualiza o cache como "aplicado" — deixa a próxima
            # confirmação/tentativa (após o cooldown) reavaliar de verdade.
            return
        log_message(f"HDMI → gamma {gamma} | brilho {brightness_r:.3f}")
        _last_hdmi_gamma = gamma
        _last_hdmi_brightness = brightness_r
    except Exception as e:
        log_message(f"Erro xrandr HDMI: {e}")


# === HDMI VIA REDSHIFT: temperatura (ganho linear) + brilho na mesma rampa ===
# Por que existe: o 'xrandr --gamma' é uma curva de potência — o topo da curva
# (branco) nunca muda, então o branco do HDMI ficava neutro enquanto o do eDP
# (sct = ganho linear por canal) ficava âmbar. O sct também não serve pro HDMI,
# porque reescreve a rampa inteira e apaga o brilho que o xrandr tinha posto.
# O redshift escreve ganho por canal E brilho na mesma rampa, num CRTC só.
# Testado à mão: 'sct 4000' + 'redshift -m randr:crtc=4 -P -O 4000 -b 0.8' deixou o
# HDMI com 'Gamma: 1.0:1.3:1.6 / Brightness: 0.80' no xrandr --verbose — mesma cor
# do sct puro (1.0:1.3:1.6), com o brilho somado.
HDMI_USE_REDSHIFT = True
REDSHIFT_BIN = "redshift"

# Leitura crua do xrandr --verbose (gamma) logo depois da última aplicação via
# redshift. É a referência do drift: em vez de comparar com a tabela do sct (que
# poderia divergir um pouco do redshift e reaplicar pra sempre = piscar), compara
# com o que o próprio xrandr leu depois de NÓS aplicarmos.
_hdmi_readback_ref = None
_redshift_missing_logged = False

def get_hdmi_raw_state():
    """
    Lê do 'xrandr --verbose' o gamma CRU (sem inverter), o brilho e o número do
    CRTC do HDMI. Só leitura — não mexe na rampa, então não causa piscar.
    Retorna (gamma_str, brightness_float, crtc_int); o que faltar vem como None.
    Sem CRTC = saída desconectada/desligada.
    """
    try:
        output = subprocess.check_output("xrandr --verbose", shell=True, text=True, timeout=5)
    except Exception as e:
        log_message(f"Erro ao ler estado bruto do HDMI: {e}")
        return None, None, None

    in_block = False
    gamma = brightness = crtc = None
    for line in output.splitlines():
        if re.match(rf'^{re.escape(HDMI_OUTPUT)}\s', line):
            in_block = True
            continue
        if in_block and re.match(r'^\S', line):
            break
        if in_block:
            m = re.search(r"Gamma:\s*([\d.]+):([\d.]+):([\d.]+)", line)
            if m:
                gamma = f"{m.group(1)}:{m.group(2)}:{m.group(3)}"
            m = re.search(r"Brightness:\s*([\d.]+)", line)
            if m:
                brightness = float(m.group(1))
            m = re.search(r"CRTC:\s*(\d+)", line)   # não casa com 'CRTCs:'
            if m:
                crtc = int(m.group(1))
    return gamma, brightness, crtc

def apply_hdmi_redshift(temp, brightness):
    global _last_hdmi_gamma, _last_hdmi_brightness, _hdmi_readback_ref
    global _last_hdmi_attempt_target, _last_hdmi_attempt_time

    temp_i = int(temp)
    brightness_r = round(brightness, 3)
    target_key = f"{temp_i}K"

    # O CRTC pode mudar (replug do cabo, reboot), então é lido a cada ciclo.
    cur_gamma, cur_brightness, crtc = get_hdmi_raw_state()
    if crtc is None:
        log_message("HDMI: sem CRTC ativo (desconectado/desligado?) → redshift pulado")
        _last_hdmi_gamma = None
        _last_hdmi_brightness = None
        return

    # Cache + confirmação real (mesmo princípio do resto do script): só pula se o
    # estado LIDO do X ainda bate com o que aplicamos.
    if _last_hdmi_gamma == target_key and _last_hdmi_brightness == brightness_r:
        brightness_ok = cur_brightness is not None and abs(cur_brightness - brightness_r) < 0.02
        gamma_ok = _hdmi_readback_ref is None or gamma_close(cur_gamma, _hdmi_readback_ref)
        if brightness_ok and gamma_ok:
            log_message(f"HDMI {target_key} | {brightness_r:.3f} OK (confirmado) → redshift pulado")
            return
        log_message(
            f"HDMI drift detectado (real: {cur_gamma} | {cur_brightness}, "
            f"ref: {_hdmi_readback_ref} | {brightness_r:.3f}) → reaplicando"
        )

    # Cooldown: não martelar o mesmo alvo que já tentamos e não confirmou.
    now_ts = time.time()
    same_target = (_last_hdmi_attempt_target == (target_key, brightness_r))
    if same_target and (now_ts - _last_hdmi_attempt_time) < HDMI_RETRY_COOLDOWN_SECONDS:
        log_message(
            f"HDMI: última tentativa p/ {target_key} | {brightness_r:.3f} foi há menos de "
            f"{HDMI_RETRY_COOLDOWN_SECONDS}s e não confirmou → aguardando cooldown"
        )
        return
    _last_hdmi_attempt_target = (target_key, brightness_r)
    _last_hdmi_attempt_time = now_ts

    # -P = parte de uma rampa neutra (uma única escrita, sem acumular em cima do
    # sct que acabou de passar por aqui). randr:crtc=N limita ao CRTC do HDMI.
    cmd = [REDSHIFT_BIN, "-m", f"randr:crtc={crtc}", "-P",
           "-O", str(temp_i), "-b", f"{brightness_r:.3f}"]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
    except Exception as e:
        log_message(f"Erro ao rodar redshift no HDMI: {e}")
        return
    if result.returncode != 0:
        log_message(
            f"redshift HDMI retornou erro (code={result.returncode}): "
            f"{(result.stderr or result.stdout).strip() or '(sem mensagem)'}"
        )
        return

    # Guarda como referência o que o xrandr lê DEPOIS da nossa aplicação.
    ref_gamma, ref_brightness, _ = get_hdmi_raw_state()
    _hdmi_readback_ref = ref_gamma
    _last_hdmi_gamma = target_key
    _last_hdmi_brightness = brightness_r
    log_message(
        f"HDMI → redshift crtc={crtc} {temp_i}K | brilho {brightness_r:.3f} "
        f"(leitura: {ref_gamma} | {ref_brightness})"
    )

def apply_hdmi(cfg):
    """Escolhe o método do HDMI: redshift (padrão) ou xrandr --gamma (fallback)."""
    global _redshift_missing_logged
    if HDMI_USE_REDSHIFT and shutil.which(REDSHIFT_BIN):
        apply_hdmi_redshift(cfg["color_temp"], cfg["hdmi_brightness"])
        return
    if HDMI_USE_REDSHIFT and not _redshift_missing_logged:
        log_message("redshift não encontrado → HDMI usando xrandr --gamma (fallback)")
        _redshift_missing_logged = True
    apply_hdmi_gamma_brightness(cfg["gamma_hdmi"], cfg["hdmi_brightness"])


# === CONTROLE DE FREQUÊNCIA eDP-1 POR FONTE DE ENERGIA ===

def is_on_ac():
    """Retorna True se o notebook estiver na tomada (ACAD/online == 1)."""
    try:
        with open(AC_ONLINE_PATH, 'r') as f:
            return f.read().strip() == "1"
    except Exception as e:
        log_message(f"Erro ao ler status AC ({AC_ONLINE_PATH}): {e} → assumindo AC")
        return True  # fallback seguro: não throttle em caso de dúvida

def get_current_edp_hz():
    """
    Lê a frequência atual do eDP-1 via xrandr (SEM --verbose).
    Procura a linha de modo marcada com '*' (ativo) no bloco do eDP-1.

    16/08/2026 -> Corrigido: estava usando 'xrandr --verbose', cujo formato
    de modos é bem diferente do xrandr normal (quebra em várias linhas,
    tipo '*current' + uma linha separada 'clock 144.00Hz'), então a regex
    '([\\d.]+)\\*' nunca batia e a função sempre retornava None — silenciosamente
    quebrado desde o início, só não aparecia porque o cache antigo nunca
    chamava essa função de novo depois da 1ª aplicação. O xrandr SEM
    --verbose usa uma tabela de modo simples ('144.00*'), que é o formato
    que essa regex realmente espera.
    Retorna um int (ex: 144 ou 60) ou None se não conseguir ler.
    """
    try:
        output = subprocess.check_output(
            "xrandr", shell=True, text=True, timeout=5
        )
        in_edp_block = False
        for line in output.splitlines():
            # Detecta início do bloco eDP-1
            if re.match(r'^eDP-1\s', line):
                in_edp_block = True
                continue
            # Sai do bloco ao encontrar outra saída
            if in_edp_block and re.match(r'^\S', line):
                break
            # Dentro do bloco: procura linha de modo ativo (contém '*')
            if in_edp_block and '*' in line:
                match = re.search(r'([\d.]+)\*', line)
                if match:
                    return round(float(match.group(1)), 2)
        return None
    except Exception as e:
        log_message(f"Erro ao ler Hz eDP-1: {e}")
        return None

def apply_edp_refresh_rate():
    """
    Aplica 144Hz (AC) ou 60Hz (bateria) ao eDP-1, mas apenas se a frequência
    atual for diferente da desejada. Segue a mesma lógica de 'pular se já estiver correto'.
    """
    global _last_edp_hz, _last_brightness

    target_hz = HZ_ON_AC if is_on_ac() else HZ_ON_BATTERY

    # 16/08/2026 -> Mesmo bug de fundo do brilho principal: o cache em memória
    #              (_last_edp_hz) não bastava — se algo externo mudasse a taxa
    #              (xrandr manual, outra ferramenta, etc), o cache continuava
    #              achando que estava tudo certo e nunca corrigia. Agora
    #              sempre confere o valor real via get_current_edp_hz() antes
    #              de pular, mesmo quando o cache já "acha" que está OK.
    if _last_edp_hz == target_hz:
        current_hz = get_current_edp_hz()
        if current_hz == target_hz:
            log_message(f"eDP-1 {target_hz}Hz OK (confirmado) → frequência pulada")
            return
        else:
            log_message(f"eDP-1 drift detectado (real: {current_hz}Hz, esperado: {target_hz}Hz) → reaplicando")
    else:
        # Confirma lendo o valor real do sistema antes de aplicar
        current_hz = get_current_edp_hz()
        if current_hz == target_hz:
            log_message(f"eDP-1 {target_hz}Hz já ativo (xrandr) → frequência pulada")
            _last_edp_hz = target_hz
            return

    # Fonte de energia mudou → invalida cache de brilho para forçar reaplicação imediata
    _last_brightness = None

    # Aplica a mudança
    source_label = "AC" if target_hz == HZ_ON_AC else "bateria"
    log_message(
        f"eDP-1: fonte={source_label} | atual={current_hz}Hz → aplicando {target_hz}Hz"
    )
    try:
        subprocess.call(
            f"xrandr --output {EDP_OUTPUT} --mode {EDP_MODE} --rate {target_hz}",
            shell=True
        )
        _last_edp_hz = target_hz
    except Exception as e:
        log_message(f"Erro ao setar frequência eDP-1: {e}")


# === INTERPOLAÇÃO ENTRE CONFIGURAÇÕES ===

def lerp(a, b, t):
    """Interpolação linear entre a e b com fator t em [0.0, 1.0]."""
    return a + (b - a) * t

def lerp_gamma(g_a, g_b, t):
    """Interpola duas strings de gamma no formato 'R:G:B'."""
    ra, ga, ba = [float(x) for x in g_a.split(":")]
    rb, gb, bb = [float(x) for x in g_b.split(":")]
    r = lerp(ra, rb, t)
    g = lerp(ga, gb, t)
    b = lerp(ba, bb, t)
    return f"{r:.2f}:{g:.2f}:{b:.2f}"

def time_to_minutes(t):
    """Converte um objeto time em minutos desde meia-noite."""
    return t.hour * 60 + t.minute + t.second / 60.0

def get_interpolated_config(now_minutes, T):
    """
    Retorna uma configuração interpolada se estiver dentro de uma janela de transição.
    Caso contrário retorna a configuração pura do período atual.
    """
    half = TRANSITION_MINUTES / 2.0

    # Monta lista de (minuto_da_virada, periodo_anterior, periodo_seguinte)
    transitions = [
        (time_to_minutes(T["MORNING_START"]),    "night",      "morning"),
        (time_to_minutes(T["AFTERNOON_START"]),  "morning",    "afternoon"),
        (time_to_minutes(T["EVENING_START"]),    "afternoon",  "evening"),
        (time_to_minutes(T["LATE_NIGHT_START"]), "evening",    "late_night"),
        # Virada de meia-noite: trata como 1440 min para facilitar a conta
        (time_to_minutes(T["NIGHT_START"]) + 1440, "late_night", "night"),
    ]

    for (pivot, period_from, period_to) in transitions:
        dist = now_minutes - pivot   # negativo = antes da virada, positivo = depois

        if -half <= dist <= half:
            # t vai de 0.0 (início da janela) até 1.0 (fim da janela)
            t = (dist + half) / TRANSITION_MINUTES
            cfg_from = SETTINGS[period_from]
            cfg_to   = SETTINGS[period_to]

            blended = {
                "brightness":      lerp(cfg_from["brightness"],      cfg_to["brightness"],      t),
                "color_temp":      lerp(cfg_from["color_temp"],      cfg_to["color_temp"],      t),
                "gamma_hdmi":      lerp_gamma(cfg_from["gamma_hdmi"], cfg_to["gamma_hdmi"],     t),
                "hdmi_brightness": lerp(cfg_from["hdmi_brightness"], cfg_to["hdmi_brightness"], t),
            }
            log_message(
                f"[TRANSIÇÃO {period_from}→{period_to}] t={t:.2f} | "
                f"brilho={int(blended['brightness'])} | temp={int(blended['color_temp'])}K"
            )
            return blended, True  # True = está em transição

    # Fora de qualquer janela → período puro
    period = get_time_period_pure(now_minutes, T)
    return SETTINGS[period], False


def get_time_period_pure(now_minutes, T):
    """Determina o período sem considerar janelas de transição."""
    morning    = time_to_minutes(T["MORNING_START"])
    afternoon  = time_to_minutes(T["AFTERNOON_START"])
    evening    = time_to_minutes(T["EVENING_START"])
    late_night = time_to_minutes(T["LATE_NIGHT_START"])

    if now_minutes < morning:
        return "night"
    elif now_minutes < afternoon:
        return "morning"
    elif now_minutes < evening:
        return "afternoon"
    elif now_minutes < late_night:
        return "evening"
    else:
        return "late_night"


# === LOOP PRINCIPAL ===
while True:
    time.sleep(2)
    now = datetime.now()
    t_now = now.time()
    now_minutes = time_to_minutes(t_now)

    # Atualiza os perfis evening (gaming/movie) e afternoon (gaming/normal)
    # de acordo com o CPU governor, ANTES de calcular a config do ciclo,
    # para já valer neste mesmo ciclo.
    update_evening_profile()
    update_afternoon_profile()

    T_DAILY = get_daily_transitions()

    cfg, in_transition = get_interpolated_config(now_minutes, T_DAILY)

    # Log de status
    period_label = "TRANSIÇÃO" if in_transition else get_time_period_pure(now_minutes, T_DAILY).upper()
    log_message(
        f"=== {now.strftime('%H:%M:%S')} | Período: {period_label} | "
        f"Morning: {T_DAILY['MORNING_START']} | Evening: {T_DAILY['EVENING_START']} | "
        f"Late Night: {T_DAILY['LATE_NIGHT_START']} ==="
    )

    if is_monitor_off():
        log_message("Monitor off → pulando")
        time.sleep(12)
        continue

    # 1. Brilho principal
    set_brightness(cfg["brightness"])

    # 2. sct no principal
    # Durante transição, aplica sct a cada ciclo para acompanhar a interpolação.
    # Fora de transição, verifica se gamma já está correto antes de aplicar.
    if in_transition:
        apply_sct(cfg["color_temp"])
    else:
        current_gamma = get_current_gamma_primary()
        # 14/08/2026 -> Alinhado com as novas temperaturas dos SETTINGS:
        #              morning 4000K.
        #              4000K usa valor interpolado a partir do anterior 4500K.
        # 16/08/2026 -> evening agora tem 2 valores possíveis (perfil
        #              gaming/movie alternado por update_evening_profile):
        #              4300K (gaming) e 3500K (movie, original).
        expected_sct_gamma = {
            2700: "1.0:1.5:2.6",
            3000: "1.0:1.4:2.2",   # late_night
            3500: "1.0:1.3:1.9",   # evening — perfil movie
            4000: "1.0:1.25:1.65", # morning
            4300: "1.0:1.22:1.49", # evening — perfil gaming
            6500: "1.0:1.0:1.0"
        }.get(int(cfg["color_temp"]))

        if not gamma_close(current_gamma, expected_sct_gamma):
            log_message(f"Gamma principal errado ({current_gamma}) → aplicando sct {int(cfg['color_temp'])}K")
            apply_sct(cfg["color_temp"])
            time.sleep(1.5)
        else:
            log_message(f"Gamma principal {int(cfg['color_temp'])}K OK → sct pulado")

    # 3. HDMI: temperatura (mesmo color_temp do eDP) + brilho, interpolados.
    # Via redshift; cai pro xrandr --gamma (gamma_hdmi) se o redshift não existir.
    apply_hdmi(cfg)

    # 4. Frequência eDP-1: 144Hz (tomada) ou 60Hz (bateria) — pula se já estiver correto
    apply_edp_refresh_rate()

    # Durante transição, ciclo mais curto para animação mais suave
    time.sleep(3 if not in_transition else 2)
