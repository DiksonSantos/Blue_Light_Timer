#!/usr/bin/env python3
# coding: utf-8
# ================================================================
#  Brilho_Agora.py — status atual de brilho/gamma dos monitores
# ================================================================
# Substitui o antigo Brilho_Agora.sh.
# 16/08/2026 -> Criado em Python: separa por monitor (principal/externo),
#              mostra brilho em % + valor bruto do backlight, e corrige
#              a leitura do gamma do HDMI (o driver NVIDIA reporta o
#              gamma invertido via 'xrandr --verbose' — ver nota no
#              Blue_Brilho.sh de 16/08/2026). "Brightness:" do eDP-1
#              não é mais mostrado, pois não reflete o brilho real da
#              tela (o backlight não é controlado via xrandr).
# 19/09/2026 -> Reescrito para o Blue_Brilho.sh que agora aplica o HDMI via
#              redshift (ganho linear por canal + brilho na MESMA rampa):
#              * O gamma do HDMI NÃO é mais invertido. A inversão (1/x) só
#                convertia a leitura para o formato do argumento
#                'xrandr --gamma'. Com o redshift a leitura crua já está na
#                mesma convenção do eDP (sct), então os dois monitores podem
#                ser comparados direto (novo: linha "Cor vs eDP").
#              * Mostra a temperatura estimada (≈ 2700K etc.) a partir da
#                leitura, usando a mesma tabela do Blue_Brilho.sh.
#              * O brilho do HDMI agora é real (está na rampa do CRTC).
#              * A seção de log virou um resumo do script (período, sct,
#                brilho, HDMI, avisos e últimos eventos). Lê só o final do
#                arquivo, então continua rápido mesmo com o log grande.
#              Continua entendendo as linhas do método antigo (xrandr --gamma).
# ================================================================

import os
import re
import subprocess
from datetime import datetime, timedelta

# === CONFIGURAÇÕES (mesmos nomes usados no Blue_Brilho.sh) ===
HDMI_OUTPUT = "HDMI-1-0"
EDP_OUTPUT = "eDP-1"
BACKLIGHT_BRIGHTNESS_PATH = "/sys/class/backlight/intel_backlight/brightness"
BACKLIGHT_MAX_PATH = "/sys/class/backlight/intel_backlight/max_brightness"
LOG_FILE = "/tmp/pos_Blue_Brilho.log"
SERVICE_NAME = "pos_blue.service"
CPU_GOVERNOR_PATH = "/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor"
GAMING_GOVERNOR = "performance"

LOG_TAIL_BYTES = 262144        # lê só o final do log (~30 min de ciclos)
STALE_LOG_SECONDS = 60         # log mais velho que isso = script parado/pausado?
ALERT_WINDOW_MINUTES = 10      # janela para contar drift/erros
ALERT_MAX_SHOWN = 3
EVENTS_SHOWN = 4

# Leitura crua do 'xrandr --verbose' esperada para cada temperatura do sct
# (mesma tabela expected_sct_gamma do Blue_Brilho.sh).
SCT_TABLE = {
    2700: (1.0, 1.5, 2.6),
    3000: (1.0, 1.4, 2.2),    # late_night
    3500: (1.0, 1.3, 1.9),    # evening — perfil movie
    4000: (1.0, 1.25, 1.65),  # morning
    4300: (1.0, 1.22, 1.49),  # evening — perfil gaming
    6500: (1.0, 1.0, 1.0),    # afternoon
}

# === CORES ===
RESET = '\033[0m'
BOLD = '\033[1m'
DIM = '\033[2m'
WHITE = '\033[97m'
GRAY = '\033[38;5;245m'
CYAN = '\033[38;5;81m'
GREEN = '\033[38;5;114m'
YELLOW = '\033[38;5;221m'
RED = '\033[38;5;203m'

OK = f"{GREEN}✓{RESET}"
WARN = f"{YELLOW}⚠{RESET}"


def linha():
    print(f"{GRAY}────────────────────────────────────────────────────────────────{RESET}")


def secao(titulo, linha_acima=False):
    if linha_acima:
        print()
        linha()
        print(f"{BOLD}{CYAN}{titulo}{RESET}")
    else:
        print(f"\n{BOLD}{CYAN}{titulo}{RESET}")
        linha()


def campo(nome, valor):
    print(f"  {WHITE}{nome + ':':<15}{RESET} {valor}")


# === UTILIDADES DE GAMMA ===
def parse_gamma(g):
    """'1.0:1.5:2.6' -> (1.0, 1.5, 2.6); None se inválido."""
    if not g:
        return None
    try:
        r, gg, b = (float(x) for x in g.split(":"))
        return (r, gg, b)
    except ValueError:
        return None


def gamma_close(a, b, tol=0.06):
    """
    Compara duas leituras 'R:G:B' com tolerância (o xrandr arredonda ao ler
    de volta). Usa <= com folga de ponto flutuante, pelo mesmo motivo do bug
    de fronteira (diferença de exatamente 0.05) corrigido no Blue_Brilho.sh.
    """
    ta, tb = parse_gamma(a), parse_gamma(b)
    if not ta or not tb:
        return False
    return all(abs(x - y) <= tol + 1e-9 for x, y in zip(ta, tb))


def estimate_temp(g, tol=0.08):
    """Temperatura da tabela mais próxima da leitura, ou None se nenhuma bate."""
    t = parse_gamma(g)
    if not t:
        return None
    melhor = None
    for temp, ref in SCT_TABLE.items():
        d = max(abs(x - y) for x, y in zip(t, ref))
        if melhor is None or d < melhor[1]:
            melhor = (temp, d)
    return melhor[0] if melhor and melhor[1] <= tol + 1e-9 else None


def gamma_com_temp(g):
    if not g:
        return None
    temp = estimate_temp(g)
    if temp is not None:
        return f"{g}  {DIM}≈ {temp}K{RESET}"
    return f"{g}  {DIM}(fora da tabela — em transição?){RESET}"


# === LEITURA DO BACKLIGHT (monitor principal) ===
def get_backlight_percent():
    """
    Lê o brilho atual e o máximo do backlight (eDP-1) e retorna
    (percentual, valor_atual, valor_maximo). Se não conseguir ler,
    retorna (None, None, None).
    """
    try:
        with open(BACKLIGHT_BRIGHTNESS_PATH) as f:
            atual = int(f.read().strip())
        with open(BACKLIGHT_MAX_PATH) as f:
            maximo = int(f.read().strip())
        pct = round((atual / maximo) * 100) if maximo else None
        return pct, atual, maximo
    except Exception as e:
        print(f"{DIM}  (erro ao ler backlight: {e}){RESET}")
        return None, None, None


# === LEITURA DO ESTADO DE UM OUTPUT VIA xrandr --verbose ===
def get_output_state(output_name):
    """
    Lê Gamma, Brightness e CRTC de um output via 'xrandr --verbose'.
    Retorna dict {gamma, brightness, crtc}; campos ausentes = None.
    O gamma é a leitura CRUA (sem inverter). Sem CRTC = saída desligada.
    """
    estado = {"gamma": None, "brightness": None, "crtc": None}
    try:
        output = subprocess.check_output(
            "xrandr --verbose", shell=True, text=True, timeout=5
        )
    except Exception as e:
        print(f"{DIM}  (erro ao rodar xrandr: {e}){RESET}")
        return estado

    in_block = False
    for line in output.splitlines():
        if re.match(rf'^{re.escape(output_name)}\s', line):
            in_block = True
            continue
        if in_block and re.match(r'^\S', line):
            break
        if in_block:
            m = re.search(r"Gamma:\s*([\d.]+):([\d.]+):([\d.]+)", line)
            if m:
                estado["gamma"] = f"{m.group(1)}:{m.group(2)}:{m.group(3)}"
            m = re.search(r"Brightness:\s*([\d.]+)", line)
            if m:
                estado["brightness"] = float(m.group(1))
            m = re.search(r"CRTC:\s*(\d+)", line)   # não casa com 'CRTCs:'
            if m:
                estado["crtc"] = int(m.group(1))
    return estado


# === LOG ===
TS_RE = re.compile(r'^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\.\d+ - ?(.*)$')

PERIODO_RE = re.compile(
    r"^=== (\d\d:\d\d:\d\d) \| Período: (\S+) \| Morning: (\S+) \| "
    r"Evening: (\S+) \| Late Night: (\S+) ==="
)
TRANS_RE = re.compile(r"^\[TRANSIÇÃO (\w+)→(\w+)\] t=([\d.]+) \| brilho=(\d+) \| temp=(\d+)K")

SCT_APLICADO_RE = re.compile(r"^sct (\d+)K → principal")
SCT_OK_RE = re.compile(r"^Gamma principal (\d+)K OK → sct pulado")
SCT_ERRADO_RE = re.compile(r"^Gamma principal errado \((.*?)\) → aplicando sct (\d+)K")

BRILHO_APLICADO_RE = re.compile(r"^Brilho principal → (\d+) \((.+)\)")
BRILHO_OK_RE = re.compile(r"^Brilho principal (\d+) OK \(confirmado\)")
BRILHO_DRIFT_RE = re.compile(r"^Brilho principal drift detectado \(real: (\S+), esperado: (\S+)\)")

# HDMI — método novo (redshift) e antigo (xrandr --gamma)
HDMI_REDSHIFT_APLICADO_RE = re.compile(
    r"^HDMI → redshift crtc=(\d+) (\d+)K \| brilho ([\d.]+)")
HDMI_XRANDR_APLICADO_RE = re.compile(r"^HDMI → gamma (\S+) \| brilho ([\d.]+)")
HDMI_OK_RE = re.compile(r"^HDMI (\S+) \| ([\d.]+) OK \(confirmado\) → (\w+) pulado")

ALERT_RE = re.compile(r"drift|[Ee]rro|errado|cooldown|sem CRTC|não encontrado")
EVENT_RE = re.compile(
    r"^(sct \d+K → principal|Brilho principal →|HDMI → |eDP-1: fonte|Perfil )"
    r"|→ aplicando|drift|^Erro|errado"
)


def read_log_tail(path, max_bytes=LOG_TAIL_BYTES):
    """Lê só o final do arquivo (o log cresce sem parar)."""
    with open(path, "rb") as f:
        f.seek(0, os.SEEK_END)
        tamanho = f.tell()
        f.seek(max(0, tamanho - max_bytes))
        dados = f.read().decode("utf-8", errors="replace")
    linhas = dados.splitlines()
    if tamanho > max_bytes and linhas:
        linhas = linhas[1:]          # a primeira linha pode estar cortada
    return linhas


def parse_log(linhas):
    """
    Devolve [(datetime, texto)]. O cabeçalho '=== ... ===' do Blue_Brilho.sh é
    gravado numa linha SEM timestamp (o log_message começa com '\\n'), então
    ele herda o timestamp da linha anterior.
    """
    entradas = []
    ultimo_ts = None
    for l in linhas:
        if not l.strip():
            continue
        m = TS_RE.match(l)
        if m:
            ultimo_ts = datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S")
            texto = m.group(2).strip()
            if texto:
                entradas.append((ultimo_ts, texto))
        elif ultimo_ts is not None:
            entradas.append((ultimo_ts, l.strip()))
    return entradas


def find_last(entradas, *regexes):
    """Entrada mais recente que casa com algum dos regex -> (ts, texto, match, idx)."""
    for ts, texto in reversed(entradas):
        for idx, rx in enumerate(regexes):
            m = rx.search(texto)
            if m:
                return ts, texto, m, idx
    return None


def fmt_age(segundos):
    if segundos < -5:
        return "no futuro (faketime?)"
    segundos = max(0, int(segundos))
    if segundos < 60:
        return f"há {segundos}s"
    if segundos < 3600:
        return f"há {segundos // 60}min"
    h, resto = divmod(segundos, 3600)
    return f"há {h}h{resto // 60:02d}"


def age_of(ts, agora):
    return (agora - ts).total_seconds()


# === SEÇÕES ===
def service_state(log_fresco=False):
    try:
        r = subprocess.run(
            ["systemctl", "--user", "is-active", SERVICE_NAME],
            capture_output=True, text=True, timeout=3
        )
        estado = r.stdout.strip() or "desconhecido"
    except Exception:
        return f"{DIM}desconhecido (systemctl indisponível){RESET}"
    if estado == "active":
        return f"{GREEN}● ativo{RESET}"
    if estado == "activating" and log_fresco:
        return f"{YELLOW}● activating{RESET}  {DIM}(script escrevendo no log — unit provavelmente Type=simple ainda subindo){RESET}"
    return f"{RED}● {estado}{RESET}  {DIM}(systemctl --user status {SERVICE_NAME}){RESET}"


def cpu_governor():
    try:
        with open(CPU_GOVERNOR_PATH) as f:
            return f.read().strip()
    except Exception:
        return None


def hdmi_line_summary(entradas):
    """Interpreta a última linha do HDMI -> (texto_para_exibir, metodo, ts) ou None."""
    for ts, texto in reversed(entradas):
        if not texto.startswith("HDMI"):
            continue
        m = HDMI_REDSHIFT_APLICADO_RE.search(texto)
        if m:
            return (f"{m.group(2)}K | brilho {m.group(3)} {GREEN}aplicado{RESET}",
                    f"redshift · CRTC {m.group(1)}", ts)
        m = HDMI_XRANDR_APLICADO_RE.search(texto)
        if m:
            return (f"gamma {m.group(1)} | brilho {m.group(2)} {GREEN}aplicado{RESET}",
                    "xrandr --gamma (fallback)", ts)
        m = HDMI_OK_RE.search(texto)
        if m:
            metodo = "redshift" if m.group(3) == "redshift" else "xrandr --gamma (fallback)"
            return (f"{m.group(1)} | brilho {m.group(2)} {OK} confirmado", metodo, ts)
        if "drift" in texto:
            return (f"{WARN} drift detectado — reaplicando", None, ts)
        if "sem CRTC" in texto:
            return (f"{WARN} sem CRTC (desconectado/desligado?)", None, ts)
        if "cooldown" in texto:
            return (f"{WARN} aguardando cooldown (última tentativa não confirmou)", None, ts)
        return (texto, None, ts)
    return None


def secao_script(entradas, agora):
    secao(f"⚙  SCRIPT — {SERVICE_NAME}", linha_acima=True)
    campo("Serviço", service_state())

    if not entradas:
        campo("Log", f"{DIM}vazio ou sem linhas reconhecidas ({LOG_FILE}){RESET}")
        return

    # Frescor do log: última linha gravada
    ultimo_ts = entradas[-1][0]
    idade = age_of(ultimo_ts, agora)
    if idade > STALE_LOG_SECONDS:
        campo("Log", f"{WARN} sem atualização {fmt_age(idade)} — script parado?")
    monitor_off = entradas[-1][1].startswith("Monitor off")
    if monitor_off and idade <= STALE_LOG_SECONDS:
        campo("Estado", f"{YELLOW}monitor desligado (DPMS) — script em pausa{RESET}")

    # Período
    per = find_last(entradas, PERIODO_RE)
    if per:
        ts, _, m, _ = per
        rotulo = m.group(2)
        extra = ""
        if rotulo == "TRANSIÇÃO":
            tr = find_last(entradas, TRANS_RE)
            if tr:
                mt = tr[2]
                extra = f" {mt.group(1)}→{mt.group(2)}  {DIM}(t={mt.group(3)}){RESET}"
        campo("Período", f"{YELLOW}{rotulo}{RESET}{extra}  "
                         f"{DIM}(ciclo {m.group(1)}, {fmt_age(age_of(ts, agora))}){RESET}")
        campo("Horários", f"{DIM}Morning {m.group(3)} · Evening {m.group(4)} · "
                          f"Late Night {m.group(5)}{RESET}")
    else:
        campo("Período", f"{DIM}não encontrado no trecho lido do log{RESET}")

    # Governor → perfil (afternoon/evening alternam por governor)
    gov = cpu_governor()
    if gov:
        perfil = "GAMING" if gov == GAMING_GOVERNOR else "padrão (movie/normal)"
        campo("Governor", f"{gov}  {DIM}→ perfil {perfil}{RESET}")

    # sct principal
    sct = find_last(entradas, SCT_APLICADO_RE, SCT_OK_RE, SCT_ERRADO_RE)
    if sct:
        ts, _, m, idx = sct
        if idx == 0:
            txt = f"{m.group(1)}K {GREEN}aplicado{RESET}"
        elif idx == 1:
            txt = f"{m.group(1)}K {OK} confirmado"
        else:
            txt = f"{m.group(2)}K {WARN} gamma estava errado ({m.group(1)}) → corrigindo"
        campo("sct principal", f"{txt}  {DIM}({fmt_age(age_of(ts, agora))}){RESET}")

    # Brilho principal
    br = find_last(entradas, BRILHO_APLICADO_RE, BRILHO_OK_RE, BRILHO_DRIFT_RE)
    if br:
        ts, _, m, idx = br
        if idx == 0:
            txt = f"{m.group(1)} {GREEN}aplicado{RESET} {DIM}({m.group(2)}){RESET}"
        elif idx == 1:
            txt = f"{m.group(1)} {OK} confirmado"
        else:
            txt = f"{WARN} drift (real {m.group(1)}, esperado {m.group(2)}) → reaplicando"
        campo("Brilho princ.", f"{txt}  {DIM}({fmt_age(age_of(ts, agora))}){RESET}")

    # HDMI
    hd = hdmi_line_summary(entradas)
    if hd:
        txt, metodo, ts = hd
        campo("HDMI", f"{txt}  {DIM}({fmt_age(age_of(ts, agora))}){RESET}")
        if metodo:
            campo("Método HDMI", f"{DIM}{metodo}{RESET}")

    # Avisos na janela recente
    limite = agora - timedelta(minutes=ALERT_WINDOW_MINUTES)
    avisos = [(ts, t) for ts, t in entradas if ts >= limite and ALERT_RE.search(t)]
    if not avisos:
        campo("Avisos", f"{OK} nenhum drift/erro nos últimos {ALERT_WINDOW_MINUTES} min")
    else:
        campo("Avisos", f"{WARN} {len(avisos)} nos últimos {ALERT_WINDOW_MINUTES} min "
                        f"{DIM}(mais recentes abaixo){RESET}")
        for ts, t in avisos[-ALERT_MAX_SHOWN:]:
            print(f"    {YELLOW}{ts.strftime('%H:%M:%S')}  {t[:96]}{RESET}")


def secao_eventos(entradas):
    secao("📋 ÚLTIMOS EVENTOS", linha_acima=True)
    eventos = [(ts, t) for ts, t in entradas
               if EVENT_RE.search(t) and not TRANS_RE.search(t)]
    if not eventos:
        print(f"  {DIM}(nenhuma mudança/aplicação no trecho lido do log){RESET}")
        return
    for ts, t in eventos[-EVENTS_SHOWN:]:
        print(f"  {GREEN}{ts.strftime('%H:%M:%S')}  {t[:96]}{RESET}")


# === MAIN ===
def main():
    print(f"{BOLD}{CYAN}══════════════════ STATUS DE BRILHO/GAMMA ══════════════════{RESET}")

    # --- Monitor Principal ---
    secao(f"🖥  MONITOR PRINCIPAL — {EDP_OUTPUT}")
    pct, atual, maximo = get_backlight_percent()
    if pct is not None:
        campo("Brilho", f"{YELLOW}{pct}%{RESET} {DIM}({atual}/{maximo}){RESET}")
    else:
        campo("Brilho", f"{DIM}indisponível{RESET}")

    edp = get_output_state(EDP_OUTPUT)
    campo("Gamma", gamma_com_temp(edp["gamma"]) or f"{DIM}indisponível{RESET}")
    # Nota: "Brightness:" do xrandr para o eDP-1 é ignorado de propósito —
    # o backlight da tela interna não é controlado via xrandr --brightness,
    # então esse valor não reflete o brilho real (fica sempre travado em 1.0).

    # --- Monitor Externo ---
    secao(f"🖵  MONITOR EXTERNO — {HDMI_OUTPUT}")
    hdmi = get_output_state(HDMI_OUTPUT)
    if hdmi["brightness"] is not None:
        b = hdmi["brightness"]
        campo("Brilho", f"{YELLOW}{round(b * 100)}%{RESET} {DIM}({b:.3f}){RESET}")
    else:
        campo("Brilho", f"{DIM}indisponível{RESET}")
    campo("Gamma", gamma_com_temp(hdmi["gamma"])
          or f"{DIM}indisponível (monitor desconectado?){RESET}")

    # Mesma convenção de leitura nos dois monitores → comparação direta.
    if edp["gamma"] and hdmi["gamma"]:
        if gamma_close(edp["gamma"], hdmi["gamma"]):
            campo("Cor vs eDP", f"{OK} igual ao principal")
        else:
            campo("Cor vs eDP", f"{WARN} diferente do principal "
                                f"{DIM}(eDP {edp['gamma']} × HDMI {hdmi['gamma']}){RESET}")
    if hdmi["crtc"] is not None:
        campo("CRTC", f"{DIM}{hdmi['crtc']}{RESET}")

    # --- Script (lido do log) ---
    agora = datetime.now()
    try:
        entradas = parse_log(read_log_tail(LOG_FILE))
    except Exception as e:
        entradas = []
        secao(f"⚙  SCRIPT — {SERVICE_NAME}", linha_acima=True)
        campo("Serviço", service_state())
        campo("Log", f"{DIM}erro ao ler {LOG_FILE}: {e}{RESET}")
    else:
        secao_script(entradas, agora)
        secao_eventos(entradas)

    print()


if __name__ == "__main__":
    main()
